# Como gerar o APK automaticamente pelo GitHub

Este pacote inclui o projeto-fonte e um workflow que compila o APK em GitHub Actions.

1. Entre em github.com e crie um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório (incluindo a pasta oculta `.github`).
3. Abra a aba **Actions** do repositório.
4. Se necessário, habilite Actions e execute **Build Android APK** em **Run workflow**.
5. Quando terminar com sucesso, abra a execução e baixe o artefato **AI-FPS-Booster-debug-APK**.
6. Extraia o ZIP do artefato. O arquivo `app-debug.apk` é o APK de teste para instalar no aparelho.

O APK de debug é para testes. Para publicar na Play Store ou distribuir amplamente, gere uma versão release assinada.

Observação: o app atual usa regras locais de recomendação; não possui um modelo de IA treinado nem controla diretamente CPU/GPU/FPS. Ele mostra memória e estado térmico que o Android disponibiliza e sugere ajustes seguros.
