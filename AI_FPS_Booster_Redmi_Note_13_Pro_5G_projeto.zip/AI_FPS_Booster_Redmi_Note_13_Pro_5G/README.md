# AI FPS Booster — Redmi Note 13 Pro 5G

Projeto Android inicial (Kotlin, sem bibliotecas externas) para exibir memória disponível, estado térmico reportado pelo Android e recomendações seguras para jogar Free Fire.

## Importante
Este projeto **não é um APK pronto**. O ambiente em que foi preparado não tem Android SDK/Gradle para compilar e assinar um APK. O projeto pode ser aberto no Android Studio e compilado lá.

O app não promete aumentar o limite máximo de FPS. Android comum não permite que um app de terceiros controle diretamente o clock da GPU/CPU, a taxa de FPS do Free Fire ou a temperatura. O app não usa root, não altera arquivos do jogo e não encerra processos de outros aplicativos.

## Como gerar o APK
1. Instale o Android Studio em um computador.
2. Abra a pasta `AI_FPS_Booster_Redmi_Note_13_Pro_5G`.
3. Aguarde o Gradle sincronizar e aceite a instalação do Android SDK Platform 35, se solicitado.
4. Use **Build > Build APK(s)**.
5. O APK de teste ficará em `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfira o APK para o Redmi e instale. Talvez seja necessário permitir a instalação para o app de arquivos usado.

Para distribuir publicamente, gere uma versão assinada em **Build > Generate Signed Bundle / APK**.
